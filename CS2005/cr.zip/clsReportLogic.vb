Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class clsReportLogic

    Private rpt As ReportDocument

    Public WriteOnly Property CR_Rpt()
        Set(ByVal Value)
            rpt = Value
        End Set
    End Property

    Public Sub Payment_Rpt()

        Dim ds As New DataSet("dsPaymentHistory")
        Dim sqlconnect As New SqlConnection
        Dim strSQL As String
        Dim sqlda As SqlDataAdapter

        Dim strPolicy, strErrMsg As String
        Dim lngErrNo As Long
        Dim datFrom As Date
        Dim dtPAYH, dtPoList As DataTable

        strPolicy = "U9611330"
        datFrom = #1/1/2002#
        dtPAYH = objCS.GetPaymentHistory(strPolicy, datFrom, lngErrNo, strErrMsg)
        If lngErrNo = 0 Then
            Try
                ds.Tables.Add(dtPAYH)
            Catch sqlex As SqlException
            Catch ex As Exception
            End Try
        End If

        dtPoList = objCS.GetPolicySummary(strPolicy, lngErrNo, strErrMsg)
        If lngErrNo = 0 Then
            ds.Tables.Add(dtPoList)
        End If

        strSQL = "select * from PaymentTypeCodes"
        sqlconnect.ConnectionString = objSec.ConnStr("CSW", "CS2005", "CIW")

        sqlda = New SqlDataAdapter(strSQL, sqlconnect)
        sqlda.MissingSchemaAction = MissingSchemaAction.AddWithKey
        sqlda.MissingMappingAction = MissingMappingAction.Passthrough

        Try
            sqlda.Fill(ds, "PaymentTypeCodes")
        Catch sqlex As SqlClient.SqlException
            MsgBox(sqlex.Number & sqlex.ToString, MsgBoxStyle.Critical + MsgBoxStyle.OKOnly, "Error")
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical + MsgBoxStyle.OKOnly, "Error")
        End Try

        Dim filename As String = "payment.xsd"
        Dim myFileStream As New System.IO.FileStream(filename, System.IO.FileMode.Create)
        Dim MyXmlTextWriter As New System.Xml.XmlTextWriter(myFileStream, System.Text.Encoding.Unicode)
        ds.WriteXmlSchema(MyXmlTextWriter)
        MyXmlTextWriter.Close()

        rpt.SetDataSource(ds)
        rpt.Subreports("PaymentDetails").SetDataSource(ds)

        Dim crParameterFieldDefinitions As ParameterFieldDefinitions
        Dim crParameterFieldDefinition As ParameterFieldDefinition
        Dim crParameterValues As ParameterValues
        Dim crParameterDiscreteValue As New ParameterDiscreteValue

        crParameterDiscreteValue.Value = "01860360"
        'crParameterDiscreteValue.Value = CDate("8/9/1969 12:01:00 AM") 
        'crParameterDiscreteValue.Value = CInt(506) 
        'crParameterDiscreteValue.Value = CBool(True)
        'Range
        'Dim crParameterRangeValue As New ParameterRangeValue
        'With crParameterRangeValue
        '    .StartValue = "Sweden"
        '    .EndValue = "Turkey"
        '    .LowerBoundType = RangeBoundType.BoundInclusive
        '    .UpperBoundType = RangeBoundType.BoundInclusive
        'End With

        crParameterFieldDefinitions = rpt.DataDefinition.ParameterFields
        crParameterFieldDefinition = crParameterFieldDefinitions.Item("PolicyID")

        ' Add the parameter value 
        crParameterValues = crParameterFieldDefinition.CurrentValues
        crParameterValues.Add(crParameterDiscreteValue)

        ' Apply the current value to the parameter definition 
        crParameterFieldDefinition.ApplyCurrentValues(crParameterValues)

    End Sub

    Private Sub GetCrODBConn(ByRef rpt As ReportDocument)

        Dim crConnectionInfo As ConnectionInfo = New ConnectionInfo
        Dim crDatabase As Database
        Dim crTables As Tables
        Dim crTable As Table
        Dim crTableLogOnInfo As TableLogOnInfo

        With crConnectionInfo
            .ServerName = "CIW"     '** DSN
            .UserID = "vantiveuser"
            .Password = "holy321"
            .DatabaseName = ""
        End With

        crDatabase = rpt.Database
        crTables = crDatabase.Tables
        For Each crTable In crTables
            crTableLogOnInfo = crTable.LogOnInfo
            crTableLogOnInfo.ConnectionInfo = crConnectionInfo
            crTable.ApplyLogOnInfo(crTableLogOnInfo)
        Next
    End Sub

End Class
