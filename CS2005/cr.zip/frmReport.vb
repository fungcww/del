Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class frmReport
    Inherits System.Windows.Forms.Form

    Private sqldt As New DataTable
    Private ds As DataSet = New DataSet("Report")
    Private lngErr As Long = 0
    Private strErr As String = ""
    Private rpt As ReportDocument
    Private dr() As DataRow
    Private objRptLogic As New clsReportLogic

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lstReport As System.Windows.Forms.ListBox
    Private WithEvents cmdPrint As System.Windows.Forms.Button
    Friend WithEvents cmdFax As System.Windows.Forms.Button
    Friend WithEvents CrystalReportViewer1 As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents cmdPreview As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cmdPrint = New System.Windows.Forms.Button
        Me.cmdFax = New System.Windows.Forms.Button
        Me.lstReport = New System.Windows.Forms.ListBox
        Me.CrystalReportViewer1 = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.cmdPreview = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'cmdPrint
        '
        Me.cmdPrint.Location = New System.Drawing.Point(132, 284)
        Me.cmdPrint.Name = "cmdPrint"
        Me.cmdPrint.TabIndex = 0
        Me.cmdPrint.Text = "Print"
        '
        'cmdFax
        '
        Me.cmdFax.Location = New System.Drawing.Point(132, 228)
        Me.cmdFax.Name = "cmdFax"
        Me.cmdFax.TabIndex = 1
        Me.cmdFax.Text = "Fax"
        '
        'lstReport
        '
        Me.lstReport.Location = New System.Drawing.Point(8, 8)
        Me.lstReport.Name = "lstReport"
        Me.lstReport.Size = New System.Drawing.Size(200, 212)
        Me.lstReport.TabIndex = 2
        '
        'CrystalReportViewer1
        '
        Me.CrystalReportViewer1.ActiveViewIndex = -1
        Me.CrystalReportViewer1.DisplayGroupTree = False
        Me.CrystalReportViewer1.Location = New System.Drawing.Point(216, 8)
        Me.CrystalReportViewer1.Name = "CrystalReportViewer1"
        Me.CrystalReportViewer1.ReportSource = Nothing
        Me.CrystalReportViewer1.Size = New System.Drawing.Size(516, 412)
        Me.CrystalReportViewer1.TabIndex = 3
        '
        'cmdPreview
        '
        Me.cmdPreview.Location = New System.Drawing.Point(132, 256)
        Me.cmdPreview.Name = "cmdPreview"
        Me.cmdPreview.TabIndex = 4
        Me.cmdPreview.Text = "Preview"
        '
        'frmReport
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(736, 429)
        Me.Controls.Add(Me.cmdPreview)
        Me.Controls.Add(Me.CrystalReportViewer1)
        Me.Controls.Add(Me.lstReport)
        Me.Controls.Add(Me.cmdFax)
        Me.Controls.Add(Me.cmdPrint)
        Me.Name = "frmReport"
        Me.Text = "Report"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim sqlconnect As New SqlConnection
        Dim strSQL As String
        Dim sqlda As SqlDataAdapter

        strSQL = "Select * from csw_report_list where cswrel_grp_no = 2 order by cswrel_disp_name"

        sqlconnect.ConnectionString = objSec.ConnStr("CSW", "CS2005", "CIW")

        sqlda = New SqlDataAdapter(strSQL, sqlconnect)
        sqlda.MissingSchemaAction = MissingSchemaAction.AddWithKey
        sqlda.MissingMappingAction = MissingMappingAction.Passthrough

        Try
            sqlda.Fill(ds, "csw_report_list")
        Catch sqlex As SqlClient.SqlException
            MsgBox(sqlex.Number & sqlex.ToString, MsgBoxStyle.Critical + MsgBoxStyle.OKOnly, "Error")
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical + MsgBoxStyle.OKOnly, "Error")
        End Try

        lstReport.DataSource = ds.Tables("csw_report_list")
        lstReport.DisplayMember = "cswrel_disp_name"
        lstReport.ValueMember = "cswrel_rpt_no"

    End Sub

    Private Sub cmdPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPrint.Click

        If GenReport() Then
            objRptLogic.CR_Rpt = rpt
            CallByName(objRptLogic, dr(0).Item("cswrel_file_name"), CallType.Method)
            Call PrintReport(rpt, PrintDest.pdPrinter)
        End If

    End Sub

    Private Sub cmdFax_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFax.Click

        If GenReport() Then
            objRptLogic.CR_Rpt = rpt
            CallByName(objRptLogic, dr(0).Item("cswrel_file_name"), CallType.Method)
            Call PrintReport(rpt, PrintDest.pdFax)
        End If

    End Sub

    Private Sub cmdPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPreview.Click

        If GenReport() Then
            objRptLogic.CR_Rpt = rpt
            CallByName(objRptLogic, dr(0).Item("cswrel_file_name"), CallType.Method)
            Call PrintReport(rpt, PrintDest.pdPreview)
        End If

    End Sub

    Private Function GenReport() As Boolean

        If lstReport.SelectedIndex < 0 Then
            Return False
        End If

        dr = ds.Tables("csw_report_list").Select("cswrel_rpt_no = " & lstReport.SelectedValue)
        If dr.Length > 0 Then
            rpt = New ReportDocument
            rpt.Load(dr(0).Item("cswrel_file_path"))
            Return True
        End If

    End Function

    Private Sub PrintReport(ByVal rpt As ReportDocument, ByVal strDest As PrintDest)

        Select Case strDest

            Case PrintDest.pdPrinter
                ' start, end = 0 to print all
                'rpt.PrintOptions.PrinterName = dr(0).Item("cswrel_ptr_name")
                rpt.PrintOptions.PrinterName = "\\hkalvdrdev1\HPLJ4100IT1F"
                rpt.PrintToPrinter(1, True, 0, 0)

            Case PrintDest.pdPreview
                CrystalReportViewer1.ReportSource = rpt

            Case PrintDest.pdFax
                rpt.PrintOptions.PrinterName = dr(0).Item("cswrel_fax_name")
                rpt.PrintToPrinter(1, True, 0, 0)

        End Select

    End Sub

    Public Sub ExportReport(ByVal rpt As ReportDocument, ByVal strDest As String, ByVal strFormat As ExportFormatType)

        ' Export
        Dim crExportOptions As ExportOptions
        Dim crDestOptions As New DiskFileDestinationOptions

        crDestOptions.DiskFileName = strDest

        crExportOptions = rpt.ExportOptions
        crExportOptions.DestinationOptions = crDestOptions
        crExportOptions.ExportDestinationType = ExportDestinationType.DiskFile
        crExportOptions.ExportFormatType = strFormat

        rpt.Export()

    End Sub

End Class
